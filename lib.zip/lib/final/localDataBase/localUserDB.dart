import 'package:sqflite/sqflite.dart';

class UserDB {
  List<Map> medicine = [];
  List<Map> users = [];
  late Database db;

  Future<void> CreateDatabaseAndTables() async {
    db = await openDatabase(
      'user.db',
      version: 2,
      onCreate: (db, version) async {
        print("database created!");
        await _createTables(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        await db.execute('DROP TABLE IF EXISTS user');
        await db.execute('DROP TABLE IF EXISTS medicines');
        await _createTables(db);
      },
      onOpen: (db) {
        print("open database!");
      },
    );

    showData().then((value) {
      users = value;
    });
    showMedicine().then((value) {
      medicine = value;
    });
  }

  Future<void> _createTables(Database db) async {
    await db.execute('CREATE TABLE user(id INTEGER PRIMARY KEY, name TEXT, email TEXT, password TEXT)');
    print("user table created!");

    await db.execute('CREATE TABLE medicines('
        'medicine_id INTEGER PRIMARY KEY, '
        'medicine_name TEXT, '
        'medicine_effective TEXT, '
        'medicine_quantity INTEGER, '
        'medicine_sold INTEGER, '
        'medicine_price INTEGER, '
        'user_id INTEGER, '
        'FOREIGN KEY (user_id) REFERENCES user(id))');
    print("medicines table created!");
  }

  Future<void> insertUser({
    required String name,
    required String email,
    required String password,
  }) async {
    await db.transaction((txn) async {
      txn.rawInsert(
          'INSERT INTO user(name, email, password) VALUES("$name", "$email", "$password")').then((value) {
        print("inserted raw $value");
      }).catchError((e) {
        print(e);
      });
    });
  }

  Future<void> insertMedicine({
    required String name,
    required String effective,
    required int quantity,
    required int sold,
    required int price,
    required int user_id,
  }) async {
    await db.transaction((txn) async {
      txn.rawInsert(
          'INSERT INTO medicines(medicine_name, medicine_effective, medicine_quantity, medicine_sold, medicine_price, user_id) '
              'VALUES("$name", "$effective", $quantity, $sold, $price, $user_id)').then((value) {
        print("inserted raw $value");
      }).catchError((e) {
        print(e);
      });
    });
  }

  Future<void> updateUser({
    required int id,
    required String name,
    required String email,
    required String password,
  }) async {
    await db.rawUpdate(
        'UPDATE user SET name=?, email=?, password=? WHERE id=?', [name, email, password, id]);
    print("user updated");
  }

  Future<void> deleteUser({required int id}) async {
    int r = await db.rawDelete('DELETE FROM user WHERE id=?', [id]);
  }

  Future<List<Map>> showData() {
    return db.rawQuery('SELECT * FROM user');
  }

  Future<List<Map>> showMedicine() {
    return db.rawQuery('SELECT * FROM medicines');
  }
}
