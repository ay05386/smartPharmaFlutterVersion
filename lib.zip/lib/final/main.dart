
import 'package:first/final/pages/homePage.dart';
import 'package:first/final/pages/signUpPage.dart';
import 'package:first/final/pages/splashcScreen.dart';
import 'package:first/final/pages/stock.dart';
import 'package:flutter/material.dart';


void main() {
  runApp(MaterialApp(
    home: HomePage(),
  ));
}
