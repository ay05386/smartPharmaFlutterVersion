import 'package:flutter/material.dart';

import '../localDataBase/localUserDB.dart';
import 'addMedicine.dart';

class Stock extends StatefulWidget {
  const Stock({super.key});

  @override
  State<Stock> createState() => _StockState();
}

class _StockState extends State<Stock> {
  late UserDB userDatabaseStock;
  void initState() {
    // TODO: implement initState
    super.initState();
    userDatabaseStock=UserDB();
    userDatabaseStock.CreateDatabaseAndTables();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(),
      appBar: AppBar(
        title: Text("Stock",style: TextStyle(color: Colors.black),),
        actions: [
          //ACTIONS IN STOCK
          InkWell(
            onTap: (){
              Navigator.of(context).push(MaterialPageRoute(builder: (c){
                return AddMedicine();
              })
              );
            },
              child:
              Icon(Icons.more_vert_sharp,color: Colors.white,)),
        ],
      ),
      body: ListView(
        children: [
          for(int i=0;i<userDatabaseStock.medicine.length;i++)
            Row(
              children: [
                Column(
                  children: [
                    Text("${userDatabaseStock.medicine[i]['medicine_name']}"),
                    Text("${userDatabaseStock.medicine[i]['medicine_effective']}"),
                  ],
                ),
                Column(
                  children: [
                    Text("${userDatabaseStock.medicine[i]['medicine_price']}"),
                  ],
                ),
                Column(
                  children: [
                    Text("${userDatabaseStock.medicine[i]['medicine_quantity']}"),
                  ],
                ),
                Column(
                  children: [
                    Text("${userDatabaseStock.medicine[i]['medicine_price']}"),
                  ],
                ),
                Column(
                  children: [
                    Text("${userDatabaseStock.medicine[i]['medicine_quantity']}"),
                  ],
                ),

              ],
            )
        ],
      ),
    );
  }
}
