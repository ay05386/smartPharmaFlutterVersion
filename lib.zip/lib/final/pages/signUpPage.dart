
import 'package:flutter/material.dart';

import '../localDataBase/localUserDB.dart';


class SignUp extends StatefulWidget {

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  late UserDB userDatabase;
  bool T=true;
  TextEditingController password=TextEditingController();
  TextEditingController email=TextEditingController();
  TextEditingController name=TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    userDatabase=UserDB();
    userDatabase.CreateDatabaseAndTables();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("SignUp",style: TextStyle(color: Colors.black,fontSize: 25),),
        backgroundColor: Colors.orange,
      ),
      body: Column(
        children: [
          //NAME TEXT FORM FIELD
          Container(
            padding: EdgeInsets.all(10),
            child: TextFormField(
              controller: name,
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.supervised_user_circle),
                  hintText: 'write your name',
                  hintStyle: TextStyle(color: Colors.black,fontSize: 25),
                  label: Text('name',style: TextStyle(color: Colors.black,fontSize: 30),)
              ),
            ),
          ),
          //EMAIL TEXT FORM FIELD
          Container(
            padding: EdgeInsets.all(10),
            child: TextFormField(
              controller: email,
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.email_outlined),
                  hintText: 'write your email',
                  hintStyle: TextStyle(color: Colors.black,fontSize: 25),
                  label: Text('Email',style: TextStyle(color: Colors.black,fontSize: 30),)
              ),
            ),
          ),
          //PASSWORD TEXT FORM FIELD
          Container(
            padding: EdgeInsets.all(10),
            child: TextFormField(
              controller: password,
              obscureText: T,
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    onPressed: (){
                      setState(() {
                        if(T==true)
                          T=false;
                        else
                          T=true;
                      });
                    },
                    icon:Icon(Icons.remove_red_eye) ,
                  ),
                  hintText: 'write your Password',
                  hintStyle: TextStyle(color: Colors.black,fontSize: 25),
                  label: Text('Password',style: TextStyle(color: Colors.black,fontSize: 25),)
              ),
            ),
          ),
          //SIGNUP BUTTON
          MaterialButton(
            color: Colors.orange,
            onPressed:(){
              userDatabase.insertUser(
                  name: name.text,
                  email: email.text,
                  password: password.text);
              //ENTER THE LOW AND MOST SALE PAGE HERE
            } ,
            child: Text("SignUp",style: TextStyle(color: Colors.black,fontSize: 25),),
          
          )

        ],
      ),

    );
  }
}
