import 'package:flutter/material.dart';

import '../localDataBase/localUserDB.dart';


class AddMedicine extends StatefulWidget {
  const AddMedicine({super.key});

  @override
  State<AddMedicine> createState() => _AddMedicineState();
}

class _AddMedicineState extends State<AddMedicine> {
  late UserDB userDatabaseAddMedicine;
  TextEditingController name=TextEditingController();
  TextEditingController effective=TextEditingController();
  TextEditingController price=TextEditingController();
  TextEditingController quantity=TextEditingController();
  TextEditingController sold=TextEditingController();
  TextEditingController user_id=TextEditingController();
  void initState() {
    // TODO: implement initState
    super.initState();
    userDatabaseAddMedicine=UserDB();
    userDatabaseAddMedicine.CreateDatabaseAndTables();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.all(10),
            child: TextFormField(
              controller: name,
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.account_box),
                  hintText: 'write medicine name',
                  label: Text('name',style: TextStyle(color: Colors.black,fontSize: 30),)
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(10),
            child: TextFormField(
              controller: effective,
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.description),
                  hintText: 'write medicine description',
                  label: Text('description',style: TextStyle(color: Colors.black,fontSize: 30),)
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(10),
            child: TextFormField(
              controller: price,
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.numbers),
                  hintText: 'write medicine price',
                  label: Text('price',style: TextStyle(color: Colors.black,fontSize: 30),)
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(10),
            child: TextFormField(
              controller: quantity,
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.numbers),
                  hintText: 'write medicine quantity',
                  label: Text('quantity',style: TextStyle(color: Colors.black,fontSize: 30),)
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(10),
            child: TextFormField(
              controller: sold,
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.numbers),
                  hintText: 'write medicin sold',
                  label: Text('sold',style: TextStyle(color: Colors.black,fontSize: 30),)
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(10),
            child: TextFormField(
              controller: user_id,
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.numbers),
                  hintText: 'write user_id',
                  label: Text('user_id',style: TextStyle(color: Colors.black,fontSize: 30),)
              ),
            ),
          ),
          MaterialButton(
            onPressed: (){
              userDatabaseAddMedicine.insertMedicine(
                  name: name.text,
                  effective: effective.text,
                  quantity: int.parse(quantity.text),
                  sold: int.parse(sold.text),
                  price: int.parse(price.text),
                  user_id: int.parse(user_id.text));
              Navigator.of(context).pop();
            },
            child: Text("Add",style: TextStyle(color: Colors.black,fontSize: 25),),

          )

        ],
      ),
    );
  }
}
