class Chat{
  late String url,title,message,time;
  Chat({
    required this.url,
    required this.title,
    required this.message,
    required this.time

});
}