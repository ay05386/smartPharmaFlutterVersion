import 'package:flutter/material.dart';

class SubscriptionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.green,
      child: Center(
        child: Text(
          'Subscription',
          style: TextStyle(fontSize: 24, color: Colors.white),
        ),
      ),
    );
  }
}
